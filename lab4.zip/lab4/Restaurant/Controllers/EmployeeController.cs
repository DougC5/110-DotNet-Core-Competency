using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;

namespace Restaurant.Controllers
{
    public class EmployeeController: Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create([FromBody] Employee newEmp)
        {

            Data db = new Data(); // create a reference to the DB
            db.Employees.Add(newEmp); // add employee to table
            db.SaveChanges(); // save changes to DB
            db.Dispose(); // Close the connection

            Console.WriteLine("***********************");
            Console.WriteLine("Creating " + newEmp.Id);
            Console.WriteLine("Creating " + newEmp.Name);
            Console.WriteLine("Creating " + newEmp.LastName);
            Console.WriteLine("Creating " + newEmp.Position);
            Console.WriteLine("***********************");

            return Json(newEmp); // Return the Object with Assigned ID
        }
        // return all employees from database
        public IActionResult GetAll()
        {
            Data db = new Data();
            var list = db.Employees.ToList(); // Read all elements as a list
            db.Dispose();

            return Json(list);
        }
    }
}