using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Models;

namespace Restaurant.Controllers
{
    public class DishController: Controller
    {
        // Create Get method for Create Action -> View()
        public IActionResult Create()
        {
            return View();
        }

        public IActionResult List()
        {
            return View();
        }
        // Create View Page inside Dish Folder *DONE*
        // Create Menu Item *DONE*
        // Create Model for Dish *DONE*
            // name, price, img, Description, Vegan(Bool)

        // Do validations: Name and double value/ Do not send data to server "return;"

        // Create capture form on view
        // define HTTP Post for create
        // Send Data to server

        [HttpPost]
        public IActionResult Register([FromBody] Dish newDish)
        {
            Data db = new Data(); // create a reference to the DB
            db.Dishes.Add(newDish); // add dish to table
            db.SaveChanges(); // save changes to DB
            db.Dispose(); // Close the connection

            Console.WriteLine("***********************");
            Console.WriteLine("Creating " + newDish.Name);
            Console.WriteLine("Creating " + newDish.Price);
            Console.WriteLine("Creating " + newDish.Vegan);
            Console.WriteLine("***********************");

             return Json(newDish); // Return the Object with Assigned ID
        }

        public IActionResult GetAllDishes()
        {
            Data db = new Data();
            var list = db.Dishes.ToList(); // Read all elements as a list
            db.Dispose();

            return Json(list);
        }


    }
}