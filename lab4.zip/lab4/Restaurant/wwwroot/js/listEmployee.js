// *******************************
// Get Employees
// *******************************

function GetEmployees() {
    $.ajax({
        type: "GET",
        url: "/Employee/GetAll",
        contentType: "application/json; charset=utf-8",

        success: function (res) {
            console.log('Employee POST Ended');
            console.log('Server Says: ', res);
            // Display each employee as a row on the table
            displayEmployee(res);
        },

        error: function (error){
            console.log("error getting data");
            console.log(error);   
        }
    });
}

function displayEmployee(emp) {

    for (let index = 0; index < emp.length; index++) {
        const element = emp[index];
        let table = $("#tblEmployees > tbody");
        let row = `<tr>
                    <th scope="row">${element.id}</th>
                    <td>${element.name}</td>
                    <td>${element.lastName}</td>
                    <td>${element.position}</td>
                  </tr>`;

        console.log(row);
        table.append(row);
    }
}

// When employee list page loads, call this function
window.onload = GetEmployees;