// *******************************
// Get Dishes
// *******************************

function GetDishes() {
    $.ajax({
        type: "GET",
        url: "/Dish/GetAllDishes",
        contentType: "application/json; charset=utf-8",

        success: function (res) {
            console.log('Employee POST Ended');
            console.log('Server Says: ', res);
            // Display each employee as a row on the table
            displayDishes(res);
        },

        error: function (error){
            console.log("error getting data");
            console.log(error);   
        }
    });
}

function displayDishes(dish) {

    for (let index = 0; index < dish.length; index++) {
        const element = dish[index];
        let table = $("#tblDishes > tbody");
        let row = `<tr>
                    <th scope="row">${element.id}</th>
                    <td> <img style="width: 50px;" src="${element.image}"> </td>
                    <td>${element.name}</td>
                    <td>${element.price}</td>
                    <td>${element.description}</td>
                    <td>${element.vegan}</td>
                  </tr>`;

        console.log(row);
        table.append(row);
    }
}

// When employee list page loads, call this function
window.onload = GetDishes;

// public string Name {get; set;}
// public double Price {get; set;}
// public string Image {get; set;}
// public string Description {get; set;}
// public bool Vegan {get; set;}